import xbmcaddon

MainBase = 'http://pastebin.com/raw/xD7D7RFD'
addon = xbmcaddon.Addon('plugin.video.brasileirinhas - BTXG')