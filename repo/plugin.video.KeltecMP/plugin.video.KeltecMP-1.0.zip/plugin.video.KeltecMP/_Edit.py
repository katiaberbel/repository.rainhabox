import xbmcaddon

MainBase = 'http://bit.ly/keltec-mp-iptv'
addon = xbmcaddon.Addon('plugin.video.KeltecMP')